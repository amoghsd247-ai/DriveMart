<?php
$host = "sql303.byethost32.com";
$dbname = "b32_43136445_drivemart";
$username = "b32_43136445";
$password = "joshi@411008";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed.");
}

$conn->set_charset("utf8mb4");
?>