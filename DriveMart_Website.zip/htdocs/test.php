```php
<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);

echo "CHECK 1: PHP started.<br>";

require __DIR__ . '/includes/db.php';
echo "CHECK 2: Database connected.<br>";

$sql = "SELECT *
        FROM cars
        WHERE brand IS NOT NULL
          AND TRIM(brand) <> ''
          AND model IS NOT NULL
          AND TRIM(model) <> ''
          AND LOWER(TRIM(brand)) <> 'brand'
          AND LOWER(TRIM(model)) <> 'model'
          AND year > 0
          AND selling_price > 0
        ORDER BY car_id DESC";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("QUERY FAILED: " . htmlspecialchars(mysqli_error($conn)));
}

echo "CHECK 3: Browse Cars query succeeded.<br>";
echo "Cars found: " . mysqli_num_rows($result) . "<br>";

echo "CHECK 4: Loading header...<br>";
include __DIR__ . '/includes/header.php';

echo "<div style='padding:30px'>";
echo "<h2>Header loaded successfully.</h2>";
echo "<p>If you can see this, the query and header worked.</p>";
echo "</div>";

echo "CHECK 5: Loading footer...<br>";
include __DIR__ . '/includes/footer.php';

echo "<p>CHECK 6: All tests completed.</p>";
?>
```